import sqlite3

def init(database):
    conn = sqlite3.connect(database)
    conn.row_factory = sqlite3.Row
    if database == "priority_todo.db":
        conn.execute("CREATE TABLE IF NOT EXISTS PriorTODO (task TEXT NOT NULL, TODO TEXT NOT NULL, priority INTEGER NOT NULL, date DATETIME)")
    else:
        conn.execute("CREATE TABLE IF NOT EXISTS Tasks (taskID INTEGER UNIQUE, taskName TEXT NOT NULL, priority TEXT NOT NULL, project TEXT NOT NULL, assignedTo TEXT NOT NULL, startDate DATETIME NOT NULL, dueDate DATETIME NOT NULL, status TEXT NOT NULL)")
    return conn

def add_todo(database, task, todo, priority):
    conn = init(database)
    conn.execute("INSERT INTO PriorTODO (task, TODO, priority, date) VALUES (?, ?, ?, datetime('now'))", (task, todo, priority))
    conn.commit()
    conn.close()

def insert_task(database, task_id, task_name, task_priority, task_project, task_assigned_to, task_start_date, task_due_date, task_status):
    conn = init(database)
    conn.execute("INSERT INTO Tasks (taskID, taskName, priority, project, assignedTo, startDate, dueDate, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)", (task_id, task_name, task_priority, task_project, task_assigned_to, task_start_date, task_due_date, task_status))
    conn.commit()
    conn.close()

def get_todolist(database):
    conn = init(database)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM PriorTODO ORDER BY priority DESC")
    todolist = cursor.fetchall()
    conn.close()
    return todolist

def get_tasklist(database):
    conn = init(database)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Tasks")
    tasklist = cursor.fetchall()
    conn.close()
    return tasklist

def update_todo(database, old_todo, old_priority, updated_todo, updated_priority):
    conn = init(database)
    conn.execute("UPDATE PriorTODO SET TODO = ?, priority = ? WHERE TODO = ? AND priority = ?", (updated_todo, updated_priority, old_todo, old_priority))
    conn.commit()
    conn.close()

def delete_todo(database, todo):
    conn = init(database)
    conn.execute("DELETE FROM PriorTODO WHERE TODO = ?", (todo,))
    conn.commit()
    conn.close()

def delete_task(database,task_id):
    conn = init(database)
    conn.execute("DELETE FROM Tasks WHERE taskID = ?", (task_id,))
    conn.commit()
    conn.close()


