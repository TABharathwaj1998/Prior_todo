from flask import Flask, render_template, request
import CRUD

app = Flask(__name__,template_folder="template",static_folder="CSS")

database = "priority_todo.db"
task = "Banking App"
todolist_values = []
priority_values = []
todolist = 0


@app.route("/", methods=["GET", "POST"])
def home():
    global todolist
    todolist = CRUD.get_todolist(database)
    return render_template("todo.html", TodoList = todolist, Task = task)    

@app.route("/add_todo", methods=["POST"])
def add_todo():
    global todolist
    todo = request.form.get("taskinput")
    todolist_values.append(todo)
    priority = request.form.get("priorityinput")
    priority_values.append(priority)

    #if todo and priority:
    CRUD.add_todo(database, task, todo, priority)
    todolist = CRUD.get_todolist(database)

    return render_template("todo.html", TodoList = todolist, Task = task)


@app.route("/update_todo", methods=["POST"])
def update_todo():
    global todolist
    for todolist in range(len(todolist_values)):
        prior_todo = request.form.get("Edit")
        old_todo = str(prior_todo.split(" ")[0].strip())
        todo_from_list = str(todolist_values[todolist].strip())
        priority_from_list = int(priority_values[todolist].strip())
        old_priority = int(prior_todo.split(" ")[1].strip())
        updated_todo = request.form.get(todolist_values[todolist])
        updated_priority = request.form.get(priority_values[todolist])

        if old_todo == todo_from_list and old_priority == priority_from_list:
            print("old_todo is ", old_todo, " and old_priority is ", old_priority)
            print("updated_todo is ", updated_todo, " and updated_priority is ", updated_priority)
            CRUD.update_todo(database, old_todo, old_priority, updated_todo, updated_priority)
            print(f"{old_todo} and {old_priority} have been updated to '{updated_todo}' with priority {updated_priority}.")
            todolist_values[todolist] = updated_todo
            priority_values[todolist] = updated_priority
            break
    todolist = CRUD.get_todolist(database)
    return render_template("todo.html", TodoList=todolist, Task=task)
    

@app.route("/completed_todo", methods=["POST"])
def completed_todo():
    global todolist
    for todolist in range(len(todolist_values)):
        todo_to_delete = request.form.get(todolist_values[todolist])
        todo_to_delete = str(todo_to_delete)
        if todo_to_delete == "Completed":
            CRUD.delete_todo(database, todolist_values[todolist])
            print(todolist_values[todolist], " is removed from the list") 
            todolist_values.pop(todolist)
            print("so the current list is ", todolist_values)
            todolist = CRUD.get_todolist(database)
            break
    return render_template("todo.html", TodoList = todolist, Task = task)
    
if __name__ == "__main__":
    app.run(debug=True)